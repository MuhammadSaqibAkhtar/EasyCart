package Adress;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Adress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long Adress;
    private int Adresslevel;
    private int Customer_ID;
    private int Product_ID;


    protected Adress() {
    }

    protected Adress(long adress, int adresslevel, int customer_ID, int product_ID) {
        this.Adress = adress;
        this.Adresslevel = adresslevel;
        this.Product_ID = product_ID;
    }
    // getters and setters are not shown for brevity
}

