package Controller;

import java.util.List;

import Cart.Cart;
import Customer.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CartService {
        @Autowired
        CartRepository repocart;

        public void save(Customer customer) {
            repocart.save(customer);
        }

        public List<Cart> listAll() {
            return (List<Cart>) repocart.findAll();
        }

        public Cart get(Long id) {
            return repocart.findById(id).get();
        }

        public void delete(Long id) {
            repocart.deleteById(id);
        }

        public List<Cart> search(String keyword) { return repocart.search(keyword); }
    }