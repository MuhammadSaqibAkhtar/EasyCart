package Controller;

import Adress.Adress;
import Customer.Customer;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import java.util.List;
public interface AdressRepository extends CrudRepository<Adress, Long> {
        @Query(value = "SELECT a FROM Customer a WHERE a.name LIKE '%' || :keyword || '%'"
                + " OR a.email LIKE '%' || :keyword || '%'"
                + " OR a.address LIKE '%' || :keyword || '%'")
        public List<Adress> search(@Param("keyword") String keyword);
}
