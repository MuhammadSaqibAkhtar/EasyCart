package Controller;

import Adress.Adress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class AdressService {
    @Autowired
    static
    AdressRepository repoAdress;
    private Adress adress;

    public void save(Adress adress) {
        repoAdress.save(adress);
    }

    public List<Adress> listAll() {
        return (List<Adress>) repoAdress.findAll();
    }

    public static Adress get(Long id) {
        return repoAdress.findById(id).get();
    }

    public void delete(Long id) {
        repoAdress.deleteById(id);
    }

    public List<Adress> search(String keyword) { return repoAdress.search(keyword); }
}