package Controller;

import Cart.Cart;
import Customer.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class CartController {

    @Autowired
    private CartService cartService;
    @RequestMapping("/")
    public ModelAndView home() {
        List<Cart> listCart = cartService.listAll();
        ModelAndView mav = new ModelAndView("Cart.jsp");
        mav.addObject("listCart", listCart);
        return mav;
    }
    // handler methods will go here...
    //delete
    @RequestMapping("/delete")
    public String deleteCartForm(@RequestParam long id) {
        cartService.delete(id);
        return "redirect:/";
    }
    //edit
    @RequestMapping("/edit")
    public ModelAndView editCartForm(@RequestParam long id) {
        ModelAndView mav = new ModelAndView("web/WEB-INF/New_Cart.jsp");
        Cart cart = cartService.get(id);
        mav.addObject("cart", cart);
        return mav;
    }
    @RequestMapping("/search")
    public ModelAndView search(@RequestParam String keyword) {
        List<Cart> result = cartService.search(keyword);
        ModelAndView mav = new ModelAndView("web/WEB-INF/Search.jsp");
        mav.addObject("result", result);

        return mav;
    }

}