package Controller;

import Adress.Adress;
import Cart.Cart;
import Customer.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

    @Controller
    public class AdressController {

        @Autowired
        private AdressService adressService;
        @RequestMapping("/")
        public ModelAndView home() {
            List<Adress> listCart = adressService.listAll();
            ModelAndView mav = new ModelAndView("Cart.jsp");
            mav.addObject("listCart", listCart);
            return mav;
        }
        // handler methods will go here...
        //delete
        @RequestMapping("/delete")
        public String deleteAdresstForm(@RequestParam long id) {
            adressService.delete(id);
            return "redirect:/";
        }
        //edit
        @RequestMapping("/edit")
        public ModelAndView editAdressForm(@RequestParam long id) {
            ModelAndView mav = new ModelAndView("web/WEB-INF/New_Adress.jsp");
            Adress adress = AdressService.get(id);
            mav.addObject("adress", adress);
            return mav;
        }
        @RequestMapping("/search")
        public ModelAndView search(@RequestParam String keyword) {
            List<Adress> result = adressService.search(keyword);
            ModelAndView mav = new ModelAndView("web/WEB-INF/Search.jsp");
            mav.addObject("result", result);

            return mav;
        }
    }