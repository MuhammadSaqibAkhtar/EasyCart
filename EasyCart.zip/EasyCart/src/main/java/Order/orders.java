package Order;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class orders {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private String Order_ID;
        private String Total;
        private String Address_ID;
        private String Customer_ID;
        private String Product_ID;
        private Boolean Paid;

        protected orders() {
        }

        protected orders(String order_ID,String total, String address_ID, String customer_ID, Boolean paid, String product_ID) {
            this.Order_ID = order_ID;
            this.Total = total;
            this.Address_ID = address_ID;
            this.Customer_ID = customer_ID;
            this.Product_ID = product_ID;
            this.Paid = paid;
        }
}
