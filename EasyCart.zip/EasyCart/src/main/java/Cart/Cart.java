package Cart;

import org.hibernate.dialect.Dialect;
import org.hibernate.sql.Select;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.awt.peer.TextComponentPeer;

@Entity
public class Cart {
    private static TextComponentPeer element;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int cart_ID;
    private int Quantity;
    private int Price;
    private boolean available;
    private int User_ID;
    private long Updatedate;
    private long Checkdate;
    private static long elemet;

    protected Cart() {
    }

    protected Cart(int cart_ID, int Quantity, int Price) {
        this.cart_ID = cart_ID;
        this.Quantity = Quantity;
        this.Price = Price;
    }
    static Actions action;

    public static void setText(String s, WebElement txtQuantity) {
    }

    public static void performMouseHower(WebElement element, WebDriver driver)
    {
        action = new Actions(driver);
        action.moveToElement(element).build().perform();
    }
    public static void click(WebElement element)
    {
        element.click();
    }
    public static void clear(WebElement element)
    {
        element.clear();
    }
    public static void selectByVisibleText(WebElement selectSize, String text)
    {
        Select s = new Select((Dialect) selectSize);
        s.equals(text);
    }
    public static void clickUsingJavaScriptExecutor(WebElement element, WebDriver driver)
    {
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("argument[0].click();",elemet);
    }

    public static void refresh(WebDriver driver) {
        driver.navigate().refresh();
    }

    public static boolean validateText(WebDriver driver, WebElement cartText, String s) {
        String observedText = element.getText();
        System.out.println(observedText);

        return false;
    }
    // getters and setters are not shown for brevity
}
