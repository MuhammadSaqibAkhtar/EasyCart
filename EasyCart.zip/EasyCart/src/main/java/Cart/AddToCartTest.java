package Cart;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AddToCartTest {
    WebDriver driver;
    Addtocart page;
    @BeforeTest
    public void setup(){
        System.setProperty("webdriver.chrome.driver", "C:\\to\\chromedriver.exe");
        WebDriver driver;
        driver = new ChromeDriver();
        driver.get("https://D:/easycart-ui-master/easycart-ui-master/src/main/resources/templates/index.html");
        driver.manage().window().maximize();
        page=new Addtocart(driver);

    }
    @Test
    public void validateAddToCart()
    {
        Assert.assertTrue(page.validationAddToCart(driver));
    }
}
