package Cart;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Addtocart {
    @FindBy(xpath="//*[@id = \"homefeatured\"]/li[2]/div/div[1]/div/a[1]/img")
    WebElement itemImage;
    @FindBy(xpath="//*[@id = \"homefeatured\"]/li[2]/div/div[2]/div[2]/a[2]")
    WebElement btnMore;
    @FindBy(xpath="//*[@id = \"quantity_wanted\"]")
     WebElement txtQuantity;
    @FindBy(xpath="//*[@id = \"group_1\"]")
    WebElement selectSize;
    @FindBy(xpath="//*[@id = \"add_to_cart\"]/button")
    WebElement btnAddtoCart;
    @FindBy(css="div#layer_cart a > span")
    WebElement btnCheckout;
    @FindBy(xpath="//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a/span[1]")
    WebElement cartText;

    Cart selenium;
    public Addtocart(WebDriver driver)
    {
        PageFactory.initElements(driver,this);
        Cart cart = new Cart();
    }
    public boolean validationAddToCart(WebDriver driver)
    {
        Cart.performMouseHower(itemImage,driver);
        Cart.click(btnMore);
        Cart.clear(txtQuantity);
        Cart.setText("3",txtQuantity);
        Cart.selectByVisibleText(selectSize,"text");
        Cart.click(btnAddtoCart);
        Cart.clickUsingJavaScriptExecutor(btnCheckout, driver);
        Cart.refresh(driver);

        return Cart.validateText(driver,cartText, "3");
    }
}
