package Customer;

import Cart.Cart;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Customer extends Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String Name;
    private String Email;
    private String Address;
    private String Customer_ID;
    private String Password;

    protected Customer() {
    }

    protected Customer(String name, String email, String address, String customer_ID, String password) {
        this.Name = name;
        this.Email = email;
        this.Address = address;
        this.Customer_ID = customer_ID;
        this.Password = password;
    }

    // getters and setters are not shown for brevity

}